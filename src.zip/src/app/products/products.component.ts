import { Component, OnInit } from '@angular/core';
import { ProductdataService} from "../productdata.service";

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
 dataListing:Array<Object>=[];
  constructor(private dataservice:ProductdataService) { }

  ngOnInit(): void {
    this.dataListing = this.dataservice.getAllProducts();
  }

}
