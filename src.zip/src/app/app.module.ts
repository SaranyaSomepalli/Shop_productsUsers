import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { UsersComponent } from './users/users.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProductComponent } from './product/product.component';
import { HeaderComponent } from './header/header.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { ServicesComponent } from './services/services.component';
import { ContactComponent } from './contact/contact.component';
import { ProductcardComponent } from './productcard/productcard.component';
import { UsercardsComponent } from './usercards/usercards.component';
import { EditComponent } from './edit/edit.component';
import { DashcontentComponent } from './dashcontent/dashcontent.component';
import { CreateProductComponent } from './create-product/create-product.component';
import { UserComponent } from './user/user.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { Edit1Component } from './edit1/edit1.component';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    UsersComponent,
    DashboardComponent,
    ProductComponent,
    HeaderComponent,
    AboutComponent,
    HomeComponent,
    ServicesComponent,
    ContactComponent,
    ProductcardComponent,
    UsercardsComponent,
    EditComponent,
    DashcontentComponent,
    CreateProductComponent,
    UserComponent,
    CreateUserComponent,
    Edit1Component,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
