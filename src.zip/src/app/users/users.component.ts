import { Component, OnInit } from '@angular/core';
import { UserdataService } from '../userdata.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  userListing:Array<Object>=[];
  constructor(private userservice:UserdataService) { }


  ngOnInit(): void {
    this.userListing = this.userservice.getAllUsers();
  }

}
