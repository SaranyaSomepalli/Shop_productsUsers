import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup,FormArray, FormBuilder, Validators} from "@angular/forms";
import { Router } from '@angular/router';
import { ProductdataService } from "../productdata.service"

@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.css']
})
export class CreateProductComponent implements OnInit {
  productFormGroup:any;
  constructor(private fb:FormBuilder, private productdataService: ProductdataService ,private router:Router) { }

  ngOnInit(): void {
    this.productFormGroup = this.fb.group({
      name : this.fb.control('',[Validators.required,Validators.minLength(5),Validators.maxLength(50)]),
      cost : this.fb.control('',Validators.required),
      description : this.fb.control('',Validators.required)
    })
  }
  submitForm(){
    console.log(this.productFormGroup.value);
    this.productdataService.addProduct(this.productFormGroup.value)
    this.productFormGroup.reset()
    this.router.navigate( ['productList'])
  }

}
