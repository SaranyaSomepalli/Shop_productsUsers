import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserdataService {

  datau=[
    {
    id:1,
    Username: "user1",
    image:"https://paulsexcavations.com.au/wp-content/uploads/2017/11/dummy-image-5.jpg",
    Email:"user1@gm.com",
    Mobile:"+91-980798009",
    Password:"user1",
    CofirmPassword:"user1",
    Country:"India",
    State:"AP",
    City:"Guntur",
    Gender:"Female",
    ZipCode:"522006"
    
    
  },
  {
    id:2,
    Username: "user2",
    image:"https://paulsexcavations.com.au/wp-content/uploads/2017/11/dummy-image-5.jpg",
    Email:"user2@gm.com",
    Mobile:"+91-880798009",
    Password:"user2",
    CofirmPassword:"user2",
    Country:"India",
    State:"TamilNadu",
    City:"Chennai",
    Gender:"Female",
    ZipCode:"522007"
  },
  {
    id:3,
    Username: "user3",
    image:"https://www.realtechnirman.com/wp-content/uploads/2017/02/man-dummy.jpg",
    Email:"user3@gm.com",
    Mobile:"+91-680798009",
    Password:"user3",
    CofirmPassword:"user3",
    Country:"India",
    State:"Karnataka",
    City:"Banglore",
    Gender:"Male",
    ZipCode:"522005"
    
  },
  {
    id:4,
    Username: "user4",
    image:"https://www.realtechnirman.com/wp-content/uploads/2017/02/man-dummy.jpg",
    Email:"user4@gm.com",
    Mobile:"+91-670798009",
    Password:"user4",
    CofirmPassword:"user4",
    Country:"India",
    State:"AP",
    City:"Guntur",
    Gender:"Male",
    ZipCode:"522006"
    
  }
]

  constructor() { }

  getAllUsers():Array<Object>{
    return this.datau;
}
getUserById(id:number):any{
  return this.datau.find(p => p.id == id);
}
addUser(dataObj:any){
  dataObj.id = this.datau.length+1;
  dataObj.image = "https://www.realtechnirman.com/wp-content/uploads/2017/02/man-dummy.jpg"
  this.datau.push(dataObj)

}
updateUser(id:number,dataObj:any){
  let findObj = this.datau.findIndex((obj) => {
    return obj.id == id
  })
  console.log(findObj)
  dataObj.id = id;
  dataObj.image ="https://www.realtechnirman.com/wp-content/uploads/2017/02/man-dummy.jpg"
  this.datau[findObj]  = dataObj;
}
getLength(){
  return this.datau.length;
}
  
}
