import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup,FormArray, FormBuilder, Validators} from "@angular/forms";
import { Router,ActivatedRoute } from '@angular/router';
import { ObjectUnsubscribedError } from 'rxjs';
import { ProductdataService } from "../productdata.service"

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  productFormGroup:any;
  constructor(private activatedRoute: ActivatedRoute, private fb:FormBuilder, private productdataService: ProductdataService ,private router:Router) { }
  

  ngOnInit(): void {
    let currentId = this.activatedRoute.snapshot.params.id;
    let currentProduct = this.productdataService.getProductById(currentId)
    this.productFormGroup = this.fb.group({
      name : this.fb.control(currentProduct.name,[Validators.required,Validators.minLength(5),Validators.maxLength(50)]),
      cost : this.fb.control(currentProduct.cost,Validators.required),
      description : this.fb.control(currentProduct.description,Validators.required)
    })
  }
  submitForm(){
    console.log(this.productFormGroup.get("name").errors)
    if(this.productFormGroup.valid){
      console.log(this.productFormGroup.value);
      this.productdataService.updateProduct(this.activatedRoute.snapshot.params.id,this.productFormGroup.value)
    this.productFormGroup.reset()
    //this.router.navigate(['productData'])

    }else{
      this.validateAllFormFields(this.productFormGroup)
    }
  }
  validateAllFormFields(formGroup: FormGroup){
    Object.keys(formGroup.controls).forEach(field =>{
      const control = formGroup.get(field);
      if(control instanceof FormControl){
        control.markAsTouched({onlySelf:true});
      }
      else if(control instanceof FormGroup){
        this.validateAllFormFields(control);
      }
      
    });
  }
}
