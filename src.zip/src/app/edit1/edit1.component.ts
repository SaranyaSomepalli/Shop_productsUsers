import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup,FormArray, FormBuilder, Validators} from "@angular/forms";
import { ActivatedRoute, Router } from '@angular/router';
import { UserdataService } from "../userdata.service"

@Component({
  selector: 'app-edit1',
  templateUrl: './edit1.component.html',
  styleUrls: ['./edit1.component.css']
})
export class Edit1Component implements OnInit {

  userFormGroup:any;
  constructor(private activatedRoute: ActivatedRoute,private fb:FormBuilder, private userdataService: UserdataService,private router:Router) { }



  ngOnInit(): void {
    let currentId = this.activatedRoute.snapshot.params.id;
    let currentUser = this.userdataService.getUserById(currentId)
    this.userFormGroup = this.fb.group({
      Username : this.fb.control(currentUser.Username,[Validators.required,Validators.minLength(5),Validators.maxLength(50)]),
      Email : this.fb.control(currentUser.Email,Validators.required),
      Mobile : this.fb.control(currentUser.Mobile,[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
      Password : this.fb.control(currentUser.Password,Validators.required),
      ConfirmPassword : this.fb.control(currentUser.ConfirmPassword,Validators.required),
      Country : this.fb.control(currentUser.Country,Validators.required),
      State : this.fb.control(currentUser.State,Validators.required),
      City : this.fb.control(currentUser.City,Validators.required),
      Gender : this.fb.control(currentUser.Gender,Validators.required),
      ZipCode : this.fb.control(currentUser?.ZipCode,Validators.required)
    })
  }
  submitForm(){
    console.log(this.userFormGroup.get("Username").errors)
    if(this.userFormGroup.valid){
      console.log(this.userFormGroup.value);
      this.userdataService.updateUser(this.activatedRoute.snapshot.params.id,this.userFormGroup.value)
    this.userFormGroup.reset()
    // this.router.navigate(['productData'])

    }else{
      this.validateAllFormFields(this.userFormGroup)
    }
  }

  validateAllFormFields(formGroup: FormGroup){
    Object.keys(formGroup.controls).forEach(field =>{
      const control = formGroup.get(field);
      if(control instanceof FormControl){
        control.markAsTouched({onlySelf:true});
      }
      else if(control instanceof FormGroup){
        this.validateAllFormFields(control);
      }
      
    });
  }

}
