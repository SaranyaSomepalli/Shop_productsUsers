
export interface userData{
    Username: string,
    image:string,
    Email:string,
    Mobile:string,
    Password:string,
    CofirmPassword:string,
    Country:string,
    State:string,
    City:string,
    Gender:string,
    ZipCode:string
}