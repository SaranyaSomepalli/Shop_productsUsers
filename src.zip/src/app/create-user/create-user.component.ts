import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup,FormArray, FormBuilder, Validators} from "@angular/forms";
import { Router } from '@angular/router';
import { UserdataService } from "../userdata.service"

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {
  userFormGroup:any;
  constructor(private fb:FormBuilder, private userdataService: UserdataService,private router:Router) { }
  

  ngOnInit(): void {
    this.userFormGroup = this.fb.group({
      Username : this.fb.control('',[Validators.required,Validators.minLength(5),Validators.maxLength(50)]),
      Email : this.fb.control('',Validators.required),
      Mobile : this.fb.control('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
      Password : this.fb.control('',Validators.required),
      ConfirmPassword : this.fb.control('',Validators.required),
      Country : this.fb.control('',Validators.required),
      State : this.fb.control('',Validators.required),
      City : this.fb.control('',Validators.required),
      Gender : this.fb.control('',Validators.required),
      ZipCode : this.fb.control('',Validators.required)
    
    })
  }
  submitForm(){
    console.log(this.userFormGroup.value);
    this.userdataService.addUser(this.userFormGroup.value)
    this.userFormGroup.reset()
  // this.router.navigate(['datau'])
  }

}
