import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductdataService {
data=[
  {
  id:1,
  name: "product1",
  image:"https://i.pinimg.com/474x/13/af/b7/13afb7e2b57a49ddf73baa56f4d4c161.jpg",
  cost: "$10",
  description:"Navy Blue shirt for girls"
  
},
{
  id:2,
  name: "product2",
  image:"https://tiimg.tistatic.com/fp/1/006/253/full-sleeves-pink-color-girls-t-shirts-551.jpg",
  cost: "$20",
  description:"pink shirt for girls"
  
},
{
  id:3,
  name: "product3",
  cost: "$30",
  image:"https://i.pinimg.com/564x/ca/61/c2/ca61c2777af9dad57bca83e4d4e6db7a.jpg",
  description:"Girls Red T-shirt"
  
},
{
  id:4,
  name: "product4",
  cost: "$40",
  image:"https://cdn.pixabay.com/photo/2017/09/03/14/41/mock-up-2710535_960_720.jpg",
  description:"Men's T-shirt"
  
},
{
  id:5,
  name: "product5",
  cost: "$50",
  image:"https://assetscdn1.paytm.com/images/catalog/product/K/KI/KIDURBAN-SCOTTIURBA589647EA42B8EF/1563266629257_0..jpg",
  description:"Men's shirt"
  
},
{
  id:6,
  name: "product6",
  cost: "$60",
  image:"https://5.imimg.com/data5/SS/WB/MY-23225499/boys-check-shirt-500x500.jpg",
  description:"Men's shirt"
 
  
}

]
  constructor() { }

  getAllProducts():Array<Object>{
      return this.data;
  }
    getProductById(id:number):any{
        return this.data.find(p => p.id == id);
    }

    addProduct(dataObj:any){
      dataObj.id = this.data.length+1;
      dataObj.image = "https://assetscdn1.paytm.com/images/catalog/product/K/KI/KIDURBAN-SCOTTIURBA589647EA42B8EF/1563266629257_0..jpg"
      this.data.push(dataObj)
      

    }
    updateProduct(id:number,dataObj:any){
      let findObj = this.data.findIndex((obj) => {
        return obj.id == id
      })
      console.log(findObj)
      dataObj.id = id;
      dataObj.image = "https://assetscdn1.paytm.com/images/catalog/product/K/KI/KIDURBAN-SCOTTIURBA589647EA42B8EF/1563266629257_0..jpg"
      this.data[findObj]  = dataObj;
    }
    getLength(){
      return this.data.length;
    }

    removeForm(i:number){
      this.data.splice(i,1);
    }
}
