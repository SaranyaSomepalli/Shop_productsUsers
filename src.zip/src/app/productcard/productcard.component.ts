import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { productData } from '../model';
import { ProductdataService } from '../productdata.service';

@Component({
  selector: 'app-productcard',
  templateUrl: './productcard.component.html',
  styleUrls: ['./productcard.component.css']
})
export class ProductcardComponent implements OnInit {
  @Input('productData') productData:Partial<productData> = {}
  constructor(private pds:ProductdataService) { }

  ngOnInit(): void {
  }
  deleteObj(i:number){
    this.pds.removeForm(i);
  }
}
