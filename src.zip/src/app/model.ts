import { ValueConverter } from "@angular/compiler/src/render3/view/template";

export interface productData{
    id: number,
    name:string,
    cost:string,
    description:string,
    image:string
}